# HKVM
Professional KVM virtualization management panel.

## Quick start
```bash
cp .env.example .env
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```

Open `http://localhost:3000`. The first registered account becomes `OWNER`.

## Included
- Authentication with Argon2
- Role-based access control
- VM ownership isolation
- Prisma schema and VM metrics
- Dashboard and health endpoint
- Socket.IO realtime gateway
- License server starter
- Docker configuration

## Important
The VM action service is intentionally a safe application layer starter. Production libvirt integration must use validated identifiers and controlled process/API calls; never interpolate user input into shell commands.

Run security and dependency reviews before production deployment.
