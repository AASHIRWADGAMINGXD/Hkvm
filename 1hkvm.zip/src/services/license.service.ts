import crypto from "node:crypto"; import os from "node:os";
export function machineFingerprint(){return crypto.createHash("sha256").update([os.hostname(),os.arch(),os.platform()].join("|")).digest("hex");}
export async function validateLicense(){return {state:"UNCONFIGURED",fingerprint:machineFingerprint()};}