import {Request,Response,NextFunction} from "express";
export function requireAuth(req:Request,res:Response,next:NextFunction){if(!(req.session as any).userId)return res.redirect("/login");next();}
export function requireRole(...roles:string[]){return (req:Request,res:Response,next:NextFunction)=>{if(!roles.includes((req.session as any).role))return res.status(403).render("errors/403");next();};}