require("dotenv").config();
const { createApp } = require("./src/app");
const { initDatabase } = require("./src/database/db");

const port = Number(process.env.PORT || 3000);
const db = initDatabase();

const app = createApp(db);
const server = app.listen(port, () => {
  console.log(`VM Panel listening on http://0.0.0.0:${port}`);
});

process.on("SIGTERM", () => server.close(() => db.close()));
process.on("SIGINT", () => server.close(() => db.close()));
