# VM Panel

A Node.js/EJS KVM/QEMU management panel foundation designed around the supplied VM-panel specification.

## Requirements

- Linux host
- Node.js 18+
- npm
- SQLite
- QEMU/KVM + libvirt/virsh for real VM operations

## Install

```bash
cp .env.example .env
npm install
npm start
```

Open `http://SERVER-IP:3000`.

## First administrator

The application intentionally does not ship with a default password. Create the first account through registration, then promote it to admin directly in SQLite:

```bash
sqlite3 data/panel.db
UPDATE users SET role='admin' WHERE username='YOUR_USERNAME';
.quit
```

Disable registration afterward:

```text
registration_enabled = 0
```

## Security

- Passwords use Argon2.
- Sessions use HTTP-only, SameSite cookies.
- Helmet and API rate limiting are enabled.
- VM identifiers and resource values are validated server-side.
- Virtualization commands use `execFile()` argument arrays rather than shell interpolation.
- Secrets are read from environment variables.
- API errors do not expose stack traces.
- Audit events are recorded.

## Virtualization adapter

`src/virtualization/service.js` is the KVM/libvirt boundary. Lifecycle commands are passed as argument arrays to `virsh`. The `create` and `reinstall` paths are intentionally conservative: configure your libvirt storage pools, cloud images, cloud-init datasource, and node networking before enabling automated provisioning.

## Important production work

Before public deployment, add/verify:

- CSRF protection on browser state-changing forms.
- Strict production HTTPS and secure cookies.
- Complete libvirt provisioning with storage/network/cloud-init.
- noVNC/VNC or SPICE proxy with authentication.
- SSH PTY proxy with server-side credentials.
- ISO upload validation/scanning and disk management.
- Real node health/statistics collection.
- PostgreSQL adapter/migrations if running multi-node.
- Background queue backed by durable storage.
- Backup/restore implementation and retention policy.
- Discord OAuth2 flow and secure token handling.
- License-server protocol and machine activation.
- Automated tests and clean-server deployment testing.

Do not expose libvirt, QEMU monitor, VNC, or SSH credentials directly to untrusted browsers.
