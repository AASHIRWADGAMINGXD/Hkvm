const fs = require("fs");
const path = require("path");
const Database = require("better-sqlite3");

function initDatabase() {
  const dbPath = process.env.DATABASE_PATH || "./data/panel.db";
  fs.mkdirSync(path.dirname(path.resolve(dbPath)), { recursive: true });
  const db = new Database(dbPath);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");

  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      email TEXT UNIQUE,
      password_hash TEXT,
      role TEXT NOT NULL DEFAULT 'user',
      avatar TEXT,
      discord_id TEXT UNIQUE,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      last_login TEXT,
      max_vms INTEGER NOT NULL DEFAULT 2,
      max_cpu INTEGER NOT NULL DEFAULT 4,
      max_ram_mb INTEGER NOT NULL DEFAULT 4096,
      max_disk_gb INTEGER NOT NULL DEFAULT 50,
      max_ipv4 INTEGER NOT NULL DEFAULT 2
    );
    CREATE TABLE IF NOT EXISTS sessions (
      sid TEXT PRIMARY KEY,
      sess TEXT NOT NULL,
      expired INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS nodes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      hostname TEXT NOT NULL,
      ssh_port INTEGER NOT NULL DEFAULT 22,
      auth_method TEXT NOT NULL DEFAULT 'key',
      status TEXT NOT NULL DEFAULT 'unknown',
      cpu_cores INTEGER NOT NULL DEFAULT 0,
      ram_mb INTEGER NOT NULL DEFAULT 0,
      disk_gb INTEGER NOT NULL DEFAULT 0,
      bridge TEXT NOT NULL DEFAULT 'br0',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS os_templates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      distribution TEXT NOT NULL,
      version TEXT NOT NULL,
      image_url TEXT,
      architecture TEXT NOT NULL DEFAULT 'x86_64',
      cloud_init INTEGER NOT NULL DEFAULT 1,
      default_username TEXT NOT NULL DEFAULT 'ubuntu',
      default_cpu INTEGER NOT NULL DEFAULT 1,
      default_ram_mb INTEGER NOT NULL DEFAULT 1024,
      default_disk_gb INTEGER NOT NULL DEFAULT 10,
      description TEXT,
      enabled INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS vms (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      owner_id INTEGER NOT NULL,
      node_id INTEGER,
      name TEXT NOT NULL,
      hostname TEXT,
      os TEXT NOT NULL,
      cpu INTEGER NOT NULL,
      ram_mb INTEGER NOT NULL,
      disk_gb INTEGER NOT NULL,
      ipv4 TEXT,
      gateway TEXT,
      dns TEXT,
      mac TEXT,
      vlan INTEGER,
      bridge TEXT,
      ssh_username TEXT,
      status TEXT NOT NULL DEFAULT 'stopped',
      qemu_name TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      last_boot TEXT,
      FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY(node_id) REFERENCES nodes(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS vm_disks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      vm_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      path TEXT NOT NULL,
      size_gb INTEGER NOT NULL,
      format TEXT NOT NULL DEFAULT 'qcow2',
      device TEXT NOT NULL DEFAULT 'vda',
      FOREIGN KEY(vm_id) REFERENCES vms(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS vm_networks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      vm_id INTEGER NOT NULL,
      ipv4 TEXT,
      gateway TEXT,
      dns TEXT,
      mac TEXT,
      vlan INTEGER,
      bridge TEXT,
      FOREIGN KEY(vm_id) REFERENCES vms(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS isos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      path TEXT NOT NULL,
      size_bytes INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS backups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      vm_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      size_bytes INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'queued',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(vm_id) REFERENCES vms(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      vm_id INTEGER,
      type TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'queued',
      progress INTEGER NOT NULL DEFAULT 0,
      message TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      finished_at TEXT,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
      FOREIGN KEY(vm_id) REFERENCES vms(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      action TEXT NOT NULL,
      target TEXT,
      ip TEXT,
      result TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS licenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      key_hash TEXT NOT NULL UNIQUE,
      plan TEXT NOT NULL,
      expires_at TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      machine_fingerprint TEXT
    );
  `);

  const defaults = {
    panel_name: process.env.PANEL_NAME || "VNVM",
    default_cpu: "1",
    default_ram_mb: "1024",
    default_disk_gb: "10",
    default_bridge: process.env.DEFAULT_BRIDGE || "br0",
    registration_enabled: "1",
    maintenance_mode: "0"
  };
  const set = db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES (?,?)");
  for (const [k,v] of Object.entries(defaults)) set.run(k,v);

  seedTemplates(db);
  return db;
}

function seedTemplates(db) {
  const count = db.prepare("SELECT COUNT(*) c FROM os_templates").get().c;
  if (count) return;
  const insert = db.prepare(`
    INSERT INTO os_templates
    (name,distribution,version,image_url,architecture,cloud_init,default_username,default_cpu,default_ram_mb,default_disk_gb,description)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)
  `);
  [
    ["Ubuntu 24.04","Ubuntu","24.04","https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img","x86_64",1,"ubuntu",1,1024,10,"Ubuntu LTS cloud image"],
    ["Debian 12","Debian","12","https://cloud.debian.org/images/cloud/bookworm/latest/debian-12-generic-amd64.qcow2","x86_64",1,"debian",1,1024,10,"Debian stable cloud image"],
    ["Fedora 42","Fedora","42","","x86_64",1,"fedora",1,1536,15,"Fedora cloud template"],
    ["AlmaLinux 9","AlmaLinux","9","","x86_64",1,"almalinux",1,1024,10,"AlmaLinux template"]
  ].forEach(x => insert.run(...x));
}

module.exports = { initDatabase };
