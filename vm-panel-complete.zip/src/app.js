const path = require("path");
const fs = require("fs");
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const http = require("http");
const { Server } = require("socket.io");
const { authRoutes } = require("./routes/auth");
const { vmRoutes } = require("./routes/vms");
const { adminRoutes } = require("./routes/admin");
const { apiRoutes } = require("./routes/api");
const { requireAuth } = require("./middleware/auth");
const { setupSocket } = require("./websocket/socket");

function createApp(db) {
  const app = express();
  const server = http.createServer(app);
  const io = new Server(server);
  app.locals.db = db;
  app.locals.io = io;

  fs.mkdirSync(path.resolve("data"), {recursive:true});
  fs.mkdirSync(path.resolve("storage"), {recursive:true});
  fs.mkdirSync(path.resolve("logs"), {recursive:true});

  app.set("view engine","ejs");
  app.set("views", path.join(__dirname,"../views"));
  app.use(helmet({ contentSecurityPolicy: false }));
  app.use(express.urlencoded({extended:false, limit:"2mb"}));
  app.use(express.json({limit:"2mb"}));
  app.use(express.static(path.join(__dirname,"../public")));
  app.use(session({
    store: new SQLiteStore({ db: "sessions.db", dir: path.resolve("data") }),
    secret: process.env.SESSION_SECRET || "development-only-change-me",
    resave:false,
    saveUninitialized:false,
    cookie:{ httpOnly:true, sameSite:"lax", secure:process.env.NODE_ENV==="production", maxAge: 1000*60*60*12 }
  }));

  app.use((req,res,next)=>{
    res.locals.user = req.session.user || null;
    res.locals.panelName = db.prepare("SELECT value FROM settings WHERE key='panel_name'").get()?.value || "VNVM";
    next();
  });

  const limiter = rateLimit({windowMs:15*60*1000, limit:150, standardHeaders:true});
  app.use("/api", limiter);

  app.get("/api/health",(req,res)=>res.json({success:true,data:{status:"ok",time:new Date().toISOString()}}));

  app.get("/", (req,res)=>res.redirect(req.session.user ? "/dashboard" : "/login"));
  app.get("/login",(req,res)=>res.render("auth/login",{error:null}));
  app.get("/register",(req,res)=>{
    const enabled = db.prepare("SELECT value FROM settings WHERE key='registration_enabled'").get()?.value === "1";
    if(!enabled) return res.status(403).render("auth/login",{error:"Registration is disabled."});
    res.render("auth/register",{error:null});
  });

  app.get("/dashboard",requireAuth,(req,res)=>{
    const uid=req.session.user.id;
    const stats = {
      total: db.prepare("SELECT COUNT(*) c FROM vms WHERE owner_id=?").get(uid).c,
      running: db.prepare("SELECT COUNT(*) c FROM vms WHERE owner_id=? AND status='running'").get(uid).c,
      stopped: db.prepare("SELECT COUNT(*) c FROM vms WHERE owner_id=? AND status!='running'").get(uid).c
    };
    const vms=db.prepare("SELECT * FROM vms WHERE owner_id=? ORDER BY id DESC LIMIT 8").all(uid);
    res.render("dashboard/index",{stats,vms});
  });

  app.use(authRoutes(db));
  app.use(vmRoutes(db));
  app.use(adminRoutes(db));
  app.use("/api",apiRoutes(db));

  app.use((err,req,res,next)=>{
    console.error(err);
    if(req.path.startsWith("/api")) return res.status(500).json({success:false,error:{code:"INTERNAL_ERROR",message:"Internal server error"}});
    res.status(500).send("Internal server error");
  });

  setupSocket(io,db);
  return server;
}

module.exports = {createApp};
