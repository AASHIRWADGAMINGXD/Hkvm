function requireAuth(req,res,next){
  if(req.session.user) return next();
  return req.path.startsWith("/api")
    ? res.status(401).json({success:false,error:{code:"AUTH_REQUIRED",message:"Authentication required"}})
    : res.redirect("/login");
}
function requireRole(role){
  return (req,res,next)=>{
    if(!req.session.user) return res.redirect("/login");
    if(req.session.user.role !== role) return res.status(403).send("Forbidden");
    next();
  };
}
module.exports={requireAuth,requireRole};
