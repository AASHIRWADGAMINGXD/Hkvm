function setupSocket(io,db){
 io.use((socket,next)=>{
   const req=socket.request;
   if(req.session && req.session.user) return next();
   next(new Error("Unauthorized"));
 });
 io.on("connection",socket=>{
   socket.on("watchTask",taskId=>{
     const t=db.prepare("SELECT * FROM tasks WHERE id=?").get(Number(taskId));
     if(!t)return;
     const timer=setInterval(()=>{
       const current=db.prepare("SELECT * FROM tasks WHERE id=?").get(Number(taskId));
       socket.emit("taskUpdate",current);
       if(!current || ["completed","failed","cancelled"].includes(current.status))clearInterval(timer);
     },500);
     socket.on("disconnect",()=>clearInterval(timer));
   });
 });
}
module.exports={setupSocket};
