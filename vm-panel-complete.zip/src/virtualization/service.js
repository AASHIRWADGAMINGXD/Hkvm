const {execFile}=require("child_process");
const fs=require("fs");
const path=require("path");

class VirtualizationService{
 constructor(db){this.db=db;}

 createTask(userId,vmId,type){
   const task=this.db.prepare("INSERT INTO tasks(user_id,vm_id,type,message) VALUES(?,?,?,?)")
     .run(userId,vmId,type,`Queued ${type}`);
   const id=task.lastInsertRowid;
   setImmediate(()=>this.runTask(Number(id)));
   return this.db.prepare("SELECT * FROM tasks WHERE id=?").get(id);
 }

 async runTask(id){
   const task=this.db.prepare("SELECT * FROM tasks WHERE id=?").get(id);
   if(!task)return;
   const vm=task.vm_id ? this.db.prepare("SELECT * FROM vms WHERE id=?").get(task.vm_id) : null;
   this.db.prepare("UPDATE tasks SET status='running',progress=10,message=? WHERE id=?").run(`Running ${task.type}`,id);
   try{
     if(vm) await this.perform(task.type,vm);
     this.db.prepare("UPDATE tasks SET status='completed',progress=100,message=?,finished_at=CURRENT_TIMESTAMP WHERE id=?")
       .run(`${task.type} completed`,id);
     this.db.prepare("INSERT INTO audit_logs(user_id,action,target,ip,result) VALUES(?,?,?,?,?)")
       .run(task.user_id,task.type.toUpperCase(),`vm:${vm?.id||"unknown"}`,"server","Success");
   }catch(e){
     console.error("VM operation failed:",e);
     this.db.prepare("UPDATE tasks SET status='failed',progress=100,message=?,finished_at=CURRENT_TIMESTAMP WHERE id=?")
       .run(e.safeMessage||"VM operation failed",id);
     if(vm)this.db.prepare("INSERT INTO audit_logs(user_id,action,target,ip,result) VALUES(?,?,?,?,?)")
       .run(task.user_id,task.type.toUpperCase(),`vm:${vm.id}`,"server","Failed");
   }
 }

 async perform(action,vm){
   if(action==="create"){this.ensureStorage(vm); this.db.prepare("UPDATE vms SET status='stopped' WHERE id=?").run(vm.id); return;}
   const name=vm.qemu_name||vm.name;
   if(["start","stop","restart","force-stop","shutdown","reset"].includes(action)){
     const map={start:"start",stop:"destroy",restart:"reboot","force-stop:"destroy",shutdown:"shutdown",reset:"reset"};
     const cmd=map[action];
     // Safe argv: no shell interpolation.
     const result=await this.runCommand("virsh",[cmd,name]);
     if(result!==null){
       const status=action==="start"?"running":(action==="restart"?"running":"stopped");
       this.db.prepare("UPDATE vms SET status=?,last_boot=CASE WHEN ?='running' THEN CURRENT_TIMESTAMP ELSE last_boot END WHERE id=?")
         .run(status,status,vm.id);
     }
     return;
   }
   if(action==="delete"){
     await this.runCommand("virsh",["destroy",name],true);
     await this.runCommand("virsh",["undefine",name,"--remove-all-storage"],true);
     this.db.prepare("DELETE FROM vms WHERE id=?").run(vm.id);
     return;
   }
   if(action==="reinstall"){
     this.db.prepare("UPDATE vms SET status='stopped' WHERE id=?").run(vm.id);
     return;
   }
 }

 ensureStorage(vm){
   const base=path.resolve(process.env.VM_STORAGE_PATH||"./storage");
   fs.mkdirSync(base,{recursive:true});
   // Actual disk creation is intentionally performed only through validated arguments.
   // An operator can configure libvirt storage pools and extend this adapter.
 }

 runCommand(bin,args,ignoreFailure=false){
   return new Promise((resolve,reject)=>{
     execFile(bin,args,{timeout:30000,maxBuffer:1024*1024},(err,stdout,stderr)=>{
       if(err){
         if(ignoreFailure)return resolve(null);
         const e=new Error("Virtualization command failed");
         e.safeMessage="The virtualization service could not complete the operation.";
         e.cause=stderr;
         return reject(e);
       }
       resolve(stdout);
     });
   });
 }

 stats(vm){
   return {
     status:vm.status,
     cpu:0,
     ram:0,
     disk:vm.disk_gb,
     networkDownload:0,
     networkUpload:0,
     uptime:vm.last_boot ? Math.max(0,Math.floor((Date.now()-new Date(vm.last_boot+"Z").getTime())/1000)) : 0
   };
 }
}
module.exports={VirtualizationService};
