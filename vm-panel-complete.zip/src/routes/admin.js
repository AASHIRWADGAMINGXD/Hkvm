const express=require("express");
const {requireRole}=require("../middleware/auth");

function adminRoutes(db){
 const r=express.Router();
 r.use("/admin",requireRole("admin"));

 r.get("/admin",(req,res)=>{
  const stats={
   users:db.prepare("SELECT COUNT(*) c FROM users").get().c,
   vms:db.prepare("SELECT COUNT(*) c FROM vms").get().c,
   running:db.prepare("SELECT COUNT(*) c FROM vms WHERE status='running'").get().c,
   nodes:db.prepare("SELECT COUNT(*) c FROM nodes").get().c
  };
  res.render("admin/index",{stats});
 });
 r.get("/admin/users",(req,res)=>res.render("admin/users",{users:db.prepare("SELECT * FROM users ORDER BY id DESC").all()}));
 r.post("/admin/users/:id/role",(req,res)=>{
  const role=["admin","user"].includes(req.body.role)?req.body.role:"user";
  db.prepare("UPDATE users SET role=? WHERE id=?").run(role,Number(req.params.id));
  res.redirect("/admin/users");
 });
 r.get("/admin/vms",(req,res)=>res.render("admin/vms",{vms:db.prepare("SELECT v.*,u.username FROM vms v JOIN users u ON u.id=v.owner_id ORDER BY v.id DESC").all()}));
 r.get("/admin/nodes",(req,res)=>res.render("admin/nodes",{nodes:db.prepare("SELECT * FROM nodes ORDER BY id DESC").all()}));
 r.post("/admin/nodes",(req,res)=>{
  const b=req.body;
  db.prepare("INSERT INTO nodes(name,hostname,ssh_port,auth_method,bridge) VALUES(?,?,?,?,?)")
   .run(b.name,b.hostname,Number(b.ssh_port||22),b.auth_method||"key",b.bridge||"br0");
  res.redirect("/admin/nodes");
 });
 r.get("/admin/templates",(req,res)=>res.render("admin/templates",{templates:db.prepare("SELECT * FROM os_templates ORDER BY id").all()}));
 r.get("/admin/logs",(req,res)=>res.render("admin/logs",{logs:db.prepare("SELECT a.*,u.username FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 500").all()}));
 r.get("/admin/settings",(req,res)=>res.render("admin/settings",{settings:db.prepare("SELECT * FROM settings ORDER BY key").all()}));
 r.post("/admin/settings",(req,res)=>{
  const update=db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
  for(const [k,v] of Object.entries(req.body)) update.run(k,String(v));
  res.redirect("/admin/settings");
 });
 return r;
}
module.exports={adminRoutes};
