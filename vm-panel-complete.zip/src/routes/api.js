const express=require("express");
const {requireAuth}=require("../middleware/auth");
const {VirtualizationService}=require("../virtualization/service");

function apiRoutes(db){
 const r=express.Router();
 const virt=new VirtualizationService(db);
 r.use(requireAuth);

 r.get("/user",(req,res)=>res.json({success:true,data:req.session.user}));
 r.get("/vms",(req,res)=>{
  const q=req.session.user.role==="admin"
   ? db.prepare("SELECT * FROM vms ORDER BY id DESC").all()
   : db.prepare("SELECT * FROM vms WHERE owner_id=? ORDER BY id DESC").all(req.session.user.id);
  res.json({success:true,data:q});
 });
 r.get("/vms/:id/stats",(req,res)=>{
  const vm=owned(db,req); if(!vm)return res.status(404).json({success:false,error:{code:"VM_NOT_FOUND",message:"VM not found"}});
  res.json({success:true,data:virt.stats(vm)});
 });
 r.post("/vms/:id/:action",(req,res)=>{
  const vm=owned(db,req); if(!vm)return res.status(404).json({success:false,error:{code:"VM_NOT_FOUND",message:"VM not found"}});
  if(!["start","stop","restart","force-stop","shutdown","reset"].includes(req.params.action))
   return res.status(400).json({success:false,error:{code:"INVALID_ACTION",message:"Invalid action"}});
  const task=virt.createTask(req.session.user.id,vm.id,req.params.action);
  res.status(202).json({success:true,data:{taskId:task.id},message:`${req.params.action} queued`});
 });
 r.get("/tasks/:id",(req,res)=>{
  const t=db.prepare("SELECT * FROM tasks WHERE id=? AND (user_id=? OR ?)").get(Number(req.params.id),req.session.user.id,req.session.user.role==="admin"?1:0);
  if(!t)return res.status(404).json({success:false,error:{code:"TASK_NOT_FOUND",message:"Task not found"}});
  res.json({success:true,data:t});
 });
 r.get("/nodes",(req,res)=>res.json({success:true,data:db.prepare("SELECT * FROM nodes ORDER BY id").all()}));
 r.get("/templates",(req,res)=>res.json({success:true,data:db.prepare("SELECT * FROM os_templates WHERE enabled=1").all()}));
 return r;
}
function owned(db,req){
 return req.session.user.role==="admin"
 ? db.prepare("SELECT * FROM vms WHERE id=?").get(Number(req.params.id))
 : db.prepare("SELECT * FROM vms WHERE id=? AND owner_id=?").get(Number(req.params.id),req.session.user.id);
}
module.exports={apiRoutes};
