const express=require("express");
const argon2=require("argon2");

function authRoutes(db){
  const r=express.Router();

  r.post("/auth/login",async(req,res)=>{
    const {identifier,password}=req.body;
    const u=db.prepare("SELECT * FROM users WHERE username=? OR email=?").get(identifier,identifier);
    if(!u || !u.password_hash || !(await argon2.verify(u.password_hash,password||""))){
      return res.status(401).render("auth/login",{error:"Invalid login details."});
    }
    req.session.regenerate(err=>{
      if(err) return res.status(500).render("auth/login",{error:"Session error."});
      req.session.user={id:u.id,username:u.username,role:u.role,email:u.email,avatar:u.avatar};
      db.prepare("UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE id=?").run(u.id);
      db.prepare("INSERT INTO audit_logs(user_id,action,target,ip,result) VALUES(?,?,?,?,?)")
        .run(u.id,"LOGIN","account",req.ip,"Success");
      res.redirect("/dashboard");
    });
  });

  r.post("/auth/register",async(req,res)=>{
    try{
      const {username,email,password}=req.body;
      if(!/^[a-zA-Z0-9_.-]{3,32}$/.test(username||"")) throw new Error("Invalid username.");
      if(!email || !password || password.length<10) throw new Error("Use a valid email and a password of at least 10 characters.");
      const hash=await argon2.hash(password);
      const info=db.prepare("INSERT INTO users(username,email,password_hash) VALUES(?,?,?)").run(username,email,hash);
      req.session.user={id:info.lastInsertRowid,username,role:"user",email};
      res.redirect("/dashboard");
    }catch(e){res.status(400).render("auth/register",{error:e.message.includes("UNIQUE")?"Username or email already exists.":e.message});}
  });

  r.post("/auth/logout",(req,res)=>req.session.destroy(()=>res.redirect("/login")));

  r.post("/auth/password",requireLogin,async(req,res)=>{
    const {currentPassword,newPassword}=req.body;
    const u=db.prepare("SELECT * FROM users WHERE id=?").get(req.session.user.id);
    if(!await argon2.verify(u.password_hash,currentPassword||"")) return res.status(400).send("Current password is incorrect.");
    if((newPassword||"").length<10) return res.status(400).send("New password must be at least 10 characters.");
    db.prepare("UPDATE users SET password_hash=? WHERE id=?").run(await argon2.hash(newPassword),u.id);
    res.redirect("/profile");
  });

  r.get("/profile",requireLogin,(req,res)=>{
    const u=db.prepare("SELECT * FROM users WHERE id=?").get(req.session.user.id);
    res.render("profile",{account:u});
  });

  return r;
}
function requireLogin(req,res,next){ if(req.session.user) next(); else res.redirect("/login"); }
module.exports={authRoutes};
