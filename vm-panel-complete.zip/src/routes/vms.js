const express=require("express");
const {requireAuth}=require("../middleware/auth");
const {VirtualizationService}=require("../virtualization/service");

function vmRoutes(db){
 const r=express.Router();
 const virt=new VirtualizationService(db);

 r.get("/vms",requireAuth,(req,res)=>{
   const vms=db.prepare("SELECT v.*, n.name node_name FROM vms v LEFT JOIN nodes n ON n.id=v.node_id WHERE v.owner_id=? ORDER BY v.id DESC").all(req.session.user.id);
   res.render("vms/list",{vms});
 });

 r.get("/vms/create",requireAuth,(req,res)=>{
   const templates=db.prepare("SELECT * FROM os_templates WHERE enabled=1 ORDER BY id").all();
   res.render("vms/create",{templates,error:null});
 });

 r.post("/vms/create",requireAuth,async(req,res)=>{
   try{
     const body=req.body, uid=req.session.user.id;
     const u=db.prepare("SELECT * FROM users WHERE id=?").get(uid);
     const count=db.prepare("SELECT COUNT(*) c FROM vms WHERE owner_id=?").get(uid).c;
     if(count>=u.max_vms) throw new Error("Your VM limit has been reached.");
     const cpu=Number(body.cpu), ram=Number(body.ram_mb), disk=Number(body.disk_gb);
     if(!Number.isInteger(cpu)||cpu<1||cpu>u.max_cpu) throw new Error("Invalid CPU allocation.");
     if(!Number.isInteger(ram)||ram<256||ram>u.max_ram_mb) throw new Error("Invalid RAM allocation.");
     if(!Number.isInteger(disk)||disk<1||disk>u.max_disk_gb) throw new Error("Invalid disk allocation.");
     if(!/^[a-zA-Z0-9][a-zA-Z0-9._-]{1,62}$/.test(body.name||"")) throw new Error("Invalid VM name.");
     const tmpl=db.prepare("SELECT * FROM os_templates WHERE id=? AND enabled=1").get(Number(body.template_id));
     if(!tmpl) throw new Error("Invalid OS template.");
     const info=db.prepare(`
       INSERT INTO vms(owner_id,name,hostname,os,cpu,ram_mb,disk_gb,ipv4,gateway,dns,mac,vlan,bridge,ssh_username,qemu_name)
       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
     `).run(uid,body.name,body.hostname||body.name,tmpl.name,cpu,ram,disk,body.ipv4||null,body.gateway||null,body.dns||null,body.mac||null,body.vlan?Number(body.vlan):null,body.bridge||process.env.DEFAULT_BRIDGE||"br0",body.ssh_username||tmpl.default_username,body.name);
     const vm=db.prepare("SELECT * FROM vms WHERE id=?").get(info.lastInsertRowid);
     const task=virt.createTask(uid,vm.id,"create");
     res.redirect(`/vms/${vm.id}?task=${task.id}`);
   }catch(e){
     const templates=db.prepare("SELECT * FROM os_templates WHERE enabled=1").all();
     res.status(400).render("vms/create",{templates,error:e.message});
   }
 });

 r.get("/vms/:id",requireAuth,(req,res)=>{
   const vm=getOwned(db,req);
   if(!vm) return res.status(404).send("VM not found");
   const task=req.query.task ? db.prepare("SELECT * FROM tasks WHERE id=?").get(Number(req.query.task)) : null;
   res.render("vms/detail",{vm,task});
 });

 r.post("/vms/:id/:action",requireAuth,async(req,res)=>{
   const vm=getOwned(db,req);
   if(!vm) return res.status(404).send("VM not found");
   const allowed=["start","stop","restart","force-stop","shutdown","reset","delete","reinstall"];
   if(!allowed.includes(req.params.action)) return res.status(400).send("Invalid action");
   const task=virt.createTask(req.session.user.id,vm.id,req.params.action);
   res.redirect(`/vms/${vm.id}?task=${task.id}`);
 });

 r.get("/vms/:id/logs",requireAuth,(req,res)=>{
   const vm=getOwned(db,req); if(!vm)return res.status(404).json({success:false});
   const logs=db.prepare("SELECT * FROM audit_logs WHERE target=? ORDER BY id DESC LIMIT 100").all(`vm:${vm.id}`);
   res.json({success:true,data:logs});
 });
 return r;
}
function getOwned(db,req){
 const id=Number(req.params.id);
 return req.session.user.role==="admin"
  ? db.prepare("SELECT * FROM vms WHERE id=?").get(id)
  : db.prepare("SELECT * FROM vms WHERE id=? AND owner_id=?").get(id,req.session.user.id);
}
module.exports={vmRoutes};
